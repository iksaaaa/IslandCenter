package com.islandcenter.app

import android.content.Context

object Prefs {
    private const val FILE = "island_center"
    fun get(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun width(context: Context) = get(context).getInt("width_dp", 190).coerceIn(150, 260)
    fun duration(context: Context) = get(context).getInt("duration_ms", 4000).coerceIn(2000, 10000)
    fun offset(context: Context) = get(context).getInt("offset_dp", 8).coerceIn(0, 80)
    fun enabled(context: Context) = get(context).getBoolean("enabled", true)
}
