package com.islandcenter.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var widthLabel: TextView
    private lateinit var durationLabel: TextView
    private lateinit var offsetLabel: TextView
    private lateinit var stateLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs.get(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 24)
            setBackgroundColor(Color.rgb(10, 13, 22))
        }
        page.addView(TextView(this).apply {
            text = "ISLAND CENTER"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        page.addView(TextView(this).apply {
            text = "LIQUID GLASS  •  DYNAMIC ISLAND\nCompact edition for Infinix Hot 8"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 18)
        })

        stateLabel = label("")
        refreshState()
        page.addView(stateLabel)
        page.addView(button("Aktifkan / nonaktifkan Island") {
            prefs.edit().putBoolean("enabled", !Prefs.enabled(this)).apply()
            refreshState()
        })
        page.addView(button("1. Aktifkan akses notifikasi") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        page.addView(button("2. Izinkan tampil di atas aplikasi") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        page.addView(button("Pratinjau Dynamic Island") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, IslandOverlayService::class.java)
                    .putExtra("title", "Island Center")
                    .putExtra("message", "Liquid Glass • Compact notification"))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        page.addView(button("Buka Notification Center") {
            startActivity(Intent(this, NotificationCenterActivity::class.java))
        })

        widthLabel = label("")
        page.addView(widthLabel)
        page.addView(SeekBar(this).apply {
            max = 110
            progress = Prefs.width(this@MainActivity) - 150
            setOnSeekBarChangeListener(seekListener { value ->
                prefs.edit().putInt("width_dp", value + 150).apply()
                widthLabel.text = "Lebar kapsul: ${value + 150} dp"
            })
        })

        offsetLabel = label("")
        page.addView(offsetLabel)
        page.addView(SeekBar(this).apply {
            max = 80
            progress = Prefs.offset(this@MainActivity)
            setOnSeekBarChangeListener(seekListener { value ->
                prefs.edit().putInt("offset_dp", value).apply()
                offsetLabel.text = "Posisi vertikal: ${value} dp dari atas"
            })
        })

        durationLabel = label("")
        page.addView(durationLabel)
        page.addView(SeekBar(this).apply {
            max = 8
            progress = (Prefs.duration(this@MainActivity) / 1000) - 2
            setOnSeekBarChangeListener(seekListener { value ->
                prefs.edit().putInt("duration_ms", (value + 2) * 1000).apply()
                durationLabel.text = "Durasi tampil: ${value + 2} detik"
            })
        })

        page.addView(TextView(this).apply {
            text = "\nCatatan: akses notifikasi membaca judul dan teks notifikasi. Riwayat disimpan lokal di perangkat."
            textSize = 11f
            setTextColor(Color.GRAY)
        })
        setContentView(page)
    }

    private fun refreshState() {
        stateLabel.text = if (Prefs.enabled(this)) "STATUS: ISLAND AKTIF" else "STATUS: ISLAND NONAKTIF"
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(Color.WHITE)
        setPadding(4, 10, 4, 0)
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
}
