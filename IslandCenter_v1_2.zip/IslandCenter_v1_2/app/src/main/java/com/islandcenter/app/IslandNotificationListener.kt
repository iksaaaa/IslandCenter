package com.islandcenter.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent
import org.json.JSONObject

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString()
            ?: sbn.packageName.substringAfterLast('.')
        val message = extras.getCharSequence("android.bigText")?.toString()
            ?: extras.getCharSequence("android.text")?.toString()
            ?: "Notifikasi baru"

        saveNotification(sbn.packageName, title, message)
        if (!Prefs.enabled(this) || !android.provider.Settings.canDrawOverlays(this)) return

        try {
            startService(Intent(this, IslandOverlayService::class.java).apply {
                putExtra("title", title.take(60))
                putExtra("message", message.take(140))
            })
        } catch (_: Exception) {
            // XOS may restrict background service starts; original system notification remains available.
        }
    }

    private fun saveNotification(pkg: String, title: String, message: String) {
        val prefs = Prefs.get(this)
        val old = try { org.json.JSONArray(prefs.getString("history", "[]")) }
                  catch (_: Exception) { org.json.JSONArray() }
        val updated = org.json.JSONArray()
        updated.put(JSONObject().apply {
            put("app", pkg.substringAfterLast('.'))
            put("title", title.take(100))
            put("message", message.take(240))
            put("time", System.currentTimeMillis())
        })
        for (i in 0 until minOf(old.length(), 39)) updated.put(old.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }
}
