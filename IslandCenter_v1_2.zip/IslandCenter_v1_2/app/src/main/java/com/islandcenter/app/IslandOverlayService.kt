package com.islandcenter.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandOverlayService : Service() {
    private var wm: WindowManager? = null
    private var island: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this) || !Prefs.enabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val title = intent?.getStringExtra("title") ?: "Island Center"
        val message = intent?.getStringExtra("message") ?: "Liquid Glass preview"
        showIsland(title, message)
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ removeIsland() }, Prefs.duration(this).toLong())
        return START_NOT_STICKY
    }

    private fun showIsland(title: String, message: String) {
        removeIsland()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(7), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(242, 12, 14, 19))
                cornerRadius = dp(25).toFloat()
                setStroke(dp(1), Color.argb(105, 220, 230, 255))
            }
            elevation = dp(9).toFloat()
            setOnClickListener {
                val open = Intent(this@IslandOverlayService, NotificationCenterActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(open)
                removeIsland()
            }
        }
        card.addView(TextView(this).apply {
            text = title
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        })
        card.addView(TextView(this).apply {
            text = message
            textSize = 10f
            setTextColor(Color.LTGRAY)
            maxLines = 2
        })
        val params = WindowManager.LayoutParams(
            dp(Prefs.width(this)),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(Prefs.offset(this))
        }
        island = card
        try { wm?.addView(card, params) } catch (_: Exception) { island = null }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun removeIsland() {
        try { island?.let { wm?.removeView(it) } } catch (_: Exception) {}
        island = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeIsland()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
