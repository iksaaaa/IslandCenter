package com.islandcenter.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationCenterActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 25, 18, 18)
            setBackgroundColor(Color.rgb(12, 15, 25))
        }
        root.addView(TextView(this).apply {
            text = "NOTIFICATION CENTER"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 12)
        })
        root.addView(Button(this).apply {
            text = "Hapus semua riwayat"
            isAllCaps = false
            setOnClickListener {
                Prefs.get(this@NotificationCenterActivity).edit().putString("history", "[]").apply()
                render()
            }
        })
        val history = try { JSONArray(Prefs.get(this).getString("history", "[]")) }
                      catch (_: Exception) { JSONArray() }

        if (history.length() == 0) {
            root.addView(TextView(this).apply {
                text = "Belum ada notifikasi tersimpan."
                setTextColor(Color.LTGRAY)
                textSize = 14f
                setPadding(0, 15, 0, 0)
            })
        } else {
            for (i in 0 until history.length()) {
                val item = history.getJSONObject(i)
                val time = SimpleDateFormat("HH:mm", Locale.getDefault())
                    .format(Date(item.optLong("time")))
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(14, 10, 14, 10)
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(Color.rgb(31, 35, 47))
                        cornerRadius = 20f
                    }
                }
                card.addView(TextView(this).apply {
                    text = "${item.optString("app")}  •  $time"
                    textSize = 10f
                    setTextColor(Color.LTGRAY)
                })
                card.addView(TextView(this).apply {
                    text = item.optString("title")
                    textSize = 13f
                    setTextColor(Color.WHITE)
                })
                card.addView(TextView(this).apply {
                    text = item.optString("message")
                    textSize = 11f
                    setTextColor(Color.LTGRAY)
                })
                val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
                root.addView(card, lp)
            }
        }
        setContentView(root)
    }
}
