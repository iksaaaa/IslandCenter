# Island Center 1.2

Android source project targeting API 28+ (Android 9+), intended for Infinix Hot 8 X650C.

## Changes in 1.2
- Adjustable capsule width (150-260 dp).
- Adjustable top offset (0-80 dp) to calibrate around the waterdrop notch.
- Adjustable display duration (2-10 seconds).
- Enable/disable overlay switch.
- Tap capsule to open Notification Center.
- Clear notification history.
- Keeps up to 40 recent notification entries locally.

## Permissions and privacy
- Notification access is required to receive notification events and read their displayed title/text.
- Display over other apps is required for the floating capsule.
- Notification title/text is stored in local SharedPreferences only. No INTERNET permission, analytics SDK, or remote upload is included.
- Do not enable notification access if you do not want this app to read notification contents.

## Build
Open this folder in Android Studio using JDK 17 and Android Gradle Plugin 8.2.2. Sync Gradle, then Build > Build APK(s).
Expected debug APK: app/build/outputs/apk/debug/app-debug.apk.

This archive is source code, not a prebuilt APK. The capsule uses a translucent surface rather than true live background blur because Android 9 does not provide a general public live-blur API for third-party overlays. Exact notch alignment must be calibrated on the physical phone.
